package com.sapient.product.product_services;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TBL_PRODUCT")
public class ProductBean {
	
	@Id
	private Long id;
	
	@Column(name="p_type")
	private String type;
	
	@Column(name="p_brand")
	private String brand;
	
	@Column(name="p_color")
	private String color;
	
	@Column(name="p_size")
	private String size;
	
	@Column(name="p_price")
	private String price;
	
	@Column(name="p_sku")
	private Long  sku;
	
	@Column(name="p_seller")
	private String seller;
	
	public ProductBean(){}

	public ProductBean(Long id, String type, String brand, String color, String size, String price, Long sku,
			String seller) {
		super();
		this.id = id;
		this.type = type;
		this.brand = brand;
		this.color = color;
		this.size = size;
		this.price = price;
		this.sku = sku;
		this.seller = seller;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getColor() {
		return color;
	}

	public void setColour(String color) {
		this.color = color;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public Long getSku() {
		return sku;
	}

	public void setSku(Long sku) {
		this.sku = sku;
	}

	public String getSeller() {
		return seller;
	}

	public void setSeller(String seller) {
		this.seller = seller;
	}

	
	

}
