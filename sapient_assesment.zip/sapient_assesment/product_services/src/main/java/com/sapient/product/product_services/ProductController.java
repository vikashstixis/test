package com.sapient.product.product_services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class ProductController {
	
	@Autowired
	ProductBeanRepository repository;
	
	@GetMapping("/product_services/brand/{brand}")
	public List<ProductBean> getProductByBrand(@PathVariable String brand){
		//List<T> findAllById(Iterable<ID> ids)
		//ProductBean beanResult=repository.findAllByBrand(brand);
		
		
		return repository.findAllByBrand(brand);
		
	}
	@GetMapping("/product_services/price/{price}")
    public  List<ProductBean> getProductByPrice(@PathVariable String price){
		
    	return repository.findAllByPrice(price);
		
	}
   @GetMapping("/product_services/color/{color}")
   public List<ProductBean> getProductByColor(@PathVariable String color){
	
	   return repository.findAllByColor(color);	
   }
   
   @GetMapping("/product_services/size/{size}")
   public List<ProductBean> getProductBySize(@PathVariable String size){
	
	   return repository.findAllBySize(size);
   }
   @GetMapping("/product_services/sku/{sku}")
   public ProductBean getProductBySKU(@PathVariable Long sku){
		
	   ProductBean productBean=repository.findBySku(sku);
	   //repository.getOne(sku);
		return productBean;
   }
   @GetMapping("/product_services/seller/{seller}")
   public Integer getProductBySeller(@PathVariable String seller){
		
	   return repository.findAllBySeller(seller).size();
	 }
}
