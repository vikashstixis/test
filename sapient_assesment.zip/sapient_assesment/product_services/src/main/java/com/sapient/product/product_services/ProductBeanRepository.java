package com.sapient.product.product_services;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface ProductBeanRepository extends JpaRepository<ProductBean, Long> {
	
	List<ProductBean> findAllByBrand(String brand);
	List<ProductBean> findAllByPrice(String price);
	List<ProductBean> findAllByColor(String color);
	List<ProductBean> findAllBySize(String size);
	ProductBean findBySku(Long sku);
	List<ProductBean> findAllBySeller(String seller);
	
	

}
