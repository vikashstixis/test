package com.sapient.product.product_services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
